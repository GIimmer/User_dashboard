from django.apps import AppConfig


class BeltReviewerConfig(AppConfig):
    name = 'belt_reviewer'
