from django.apps import AppConfig


class UserDashConfig(AppConfig):
    name = 'user_dash'
